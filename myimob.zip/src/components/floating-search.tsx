import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Home, Building, Search } from "lucide-react"

export function FloatingSearch() {
  return (
    <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50 overflow-hidden">
      <div className="bg-blue-100 rounded-2xl p-4 shadow-2xl max-w-[400px] ">
        <div className="flex gap-3 items-center">
          <Select>
            <SelectTrigger className="bg-[#3655d4] text-white border-none rounded-xl px-3 py-2 w-[90px] h-10 text-sm overflow-hidden">
              <Home className="w-3 h-3 mr-1" />
              <SelectValue placeholder="Comprar" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="buy">Comprar</SelectItem>
              <SelectItem value="rent">Alugar</SelectItem>
              <SelectItem value="sell">Vender</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="bg-[#3655d4] text-white border-none rounded-xl px-3 py-2 w-[110px] h-10 text-sm">
              <Building className="w-3 h-3 mr-1" />
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="apartment">Apartamento</SelectItem>
              <SelectItem value="house">Casa</SelectItem>
              <SelectItem value="condo">Condomínio</SelectItem>
              <SelectItem value="townhouse">Sobrado</SelectItem>
            </SelectContent>
          </Select>

          <Input
            placeholder="Selecione sua localização desejada"
            className="flex-1 border-none bg-[#f5f5f5] text-[#474747] placeholder:text-[#878787] rounded-xl px-4 py-2 h-10 text-sm"
          />

          <Button className="bg-[#3655d4] hover:bg-blue-600 text-white p-2 rounded-xl h-10 w-10 flex-shrink-0">
            <Search className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
